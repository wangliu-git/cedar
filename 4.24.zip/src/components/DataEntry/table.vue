<template>
  <div class="container">
      <table>
          <thead  border>
            <tr>
              <th>数据集名称</th>
              <th>上传时间</th>
              <th>已录入：未录入</th>
              <th>存储位置</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody  border>
            <tr>
              <td>肺癌去隐私2018</td>
              <td>个</td>
              <td>吧</td>
              <td>若干</td>
              <td>若干</td>
            </tr>
          </tbody>
        </table>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
  }
</script>

<style scoped lang="stylus" rel="stylesheet/stylus" >

table th{
  width: 865px;
  height: 45px;
  background-color: #f5f5f5;
  line-height: 45px;
  color: #000;
}
td{
  height: 41px;
  line-height: 41px;
  border 1px solid #ebebeb;
  font-size: 16px;
  margin: 10px 0;
  text-align center
  color: #666;
  cursor: pointer;
}
th{
  padding: 0 26px;
  vertical-align: inherit;
  font-weight: bold;
  text-align: -internal-center;
  font-size: 16px;
  color: #666;
}
 
</style>
