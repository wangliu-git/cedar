<template>
  <div>
      <el-button type="info" @click="loginout">退出</el-button>
    </div>
</template>

<script type="text/ecmascript-6">
  export default {
    methods: {
      loginout(){
        window.sessionStorage.clear()
        this.$router.push('/login')
      }
    },
  }
</script>

<style scoped lang="stylus" rel="stylesheet/stylus" >

 
</style>
